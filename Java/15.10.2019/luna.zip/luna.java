class luna {
	public static void main(String args[]){
			int pesoPersona = 75;
			int gravitaLuna = 17;
			int pesoLuna = (pesoPersona * gravitaLuna) / 100;
			System.out.println("Il peso sulla terra: " + pesoPersona + "\n");
			System.out.println("Il perso sulla luna: " + gravitaLuna);
		};
}