class Esercizio2 {
	public static void main(String args[]) {
		for (int x = 100; x >= 0;x--) {
			System.out.println("Numero: " + x);
		}
	}
}